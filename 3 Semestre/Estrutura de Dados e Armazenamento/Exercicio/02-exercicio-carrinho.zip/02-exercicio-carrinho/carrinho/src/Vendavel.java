public interface Vendavel {

    public abstract Double getValorVenda();
}
