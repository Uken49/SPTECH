public class Servico implements Vendavel{
    private int codigo;
    private String descricao;
    private int quantHoras;
    private double valorHora;

    @Override
    public Double getValorVenda() {
        return quantHoras * valorHora;
    }

    public Servico(int codigo, String descricao, int quantHoras, double valorHora) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.quantHoras = quantHoras;
        this.valorHora = valorHora;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getQuantHoras() {
        return quantHoras;
    }

    public void setQuantHoras(int quantHoras) {
        this.quantHoras = quantHoras;
    }

    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

    @Override
    public String toString() {
        return "Servico{" +
                "codigo='" + codigo + '\'' +
                ", descricao=" + descricao +
                ", quantHoras=" + quantHoras +
                ", valorHora=" + valorHora +
                ", valorVenda=" + getValorVenda() +
                '}';
    }
}
