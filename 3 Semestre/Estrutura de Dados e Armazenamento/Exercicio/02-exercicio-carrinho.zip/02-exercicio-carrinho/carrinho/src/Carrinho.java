import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    List<Vendavel> cart = new ArrayList<>();

    public void adicionaVendavel(Vendavel v){
        cart.add(v);
    }

    public double calculaTotalVenda(){
        double valor = 0.0;

        for (Vendavel item:
             cart) {
            valor += item.getValorVenda();
        }

        return valor;
    }

    public void exibeItensCarrinho(){
        for (Vendavel item:
                cart) {
            System.out.println(item.toString());
        }
    }

}
