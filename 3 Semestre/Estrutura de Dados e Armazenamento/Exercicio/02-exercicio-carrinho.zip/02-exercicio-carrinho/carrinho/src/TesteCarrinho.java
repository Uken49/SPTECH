import java.util.Scanner;

public class TesteCarrinho {
    public static void main(String[] args) {
        Scanner intScanner = new Scanner(System.in);
        Scanner stringScanner = new Scanner(System.in);
        Scanner doubleScanner = new Scanner(System.in);

        Carrinho carrinho = new Carrinho();

        int opcao;

        do {
            System.out.printf(
                    """
                    \nEscolha uma opção função:
                    1 - Adicionar Livro
                    2 - Adicionar Dvd
                    3 - Adicionar serviço
                    4 - Exibir itens do carrinho
                    5 - Exibir total de venda
                    6 - Fim        
                    """
            );

            opcao = intScanner.nextInt();

            switch (opcao) {
                case 1 -> { // Adicionar livro
                    System.out.println("codigo(int), precoCusto(double), nome(String)" +
                            ", autor(String), isbn(String)");
                    carrinho.adicionaVendavel(
                            new Livro(
                                    intScanner.nextInt()
                                    , doubleScanner.nextDouble()
                                    , stringScanner.next()
                                    , stringScanner.next()
                                    , stringScanner.next()
                            )
                    );
                }
                case 2 -> {
                    System.out.println("codigo(int), precoCusto(double)" +
                            ", nome(String), gravadora(String)");
                    carrinho.adicionaVendavel(
                            new Dvd(
                                    intScanner.nextInt()
                                    , doubleScanner.nextDouble()
                                    , stringScanner.next()
                                    , stringScanner.next()
                            )
                    );
                }
                case 3 -> {
                    System.out.println("codigo(int), descricao(String)" +
                            " ,quantHoras(int), valorHora(double)");
                    carrinho.adicionaVendavel(
                            new Servico(
                                    intScanner.nextInt()
                                    ,stringScanner.next()
                                    , intScanner.nextInt()
                                    , doubleScanner.nextDouble()
                            )
                    );
                }
                case 4 -> {
                    carrinho.exibeItensCarrinho();
                }
                case 5 -> {
                    System.out.println(carrinho.calculaTotalVenda());
                }
                case 6 -> {
                    return;
                }
                default -> {
                    System.out.println("Por favor, escolha uma opção válida");
                }
            }
        } while ( opcao != 6);

        intScanner.close();
        doubleScanner.close();
        stringScanner.close();
    }
}