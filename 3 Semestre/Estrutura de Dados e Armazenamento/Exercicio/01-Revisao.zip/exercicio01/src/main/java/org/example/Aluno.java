package org.example;

public abstract class Aluno {
    public Aluno(Integer ra, String nome) {
        this.ra = ra;
        this.nome = nome;
    }

    private Integer ra;
    private String nome;

    public abstract Double calcularMedia();

    @Override
    public String toString() {
        return "\nra=" + ra +
               "\nnome='" + nome;
    }

    public Integer getRa() {
        return ra;
    }

    public String getNome() {
        return nome;
    }
}
