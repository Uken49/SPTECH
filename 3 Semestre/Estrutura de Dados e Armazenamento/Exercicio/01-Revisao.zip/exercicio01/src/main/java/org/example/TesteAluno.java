package org.example;

public class TesteAluno {
    public static void main(String[] args) {

//        Criando os alunos
        AlunoFundamental af = new AlunoFundamental(123456789, "Diego", 6.0, 8.0, 8.0, 6.0);
        AlunoGraduacao ag = new AlunoGraduacao(234567890, "Marise", 9.0, 10.0);
        AlunoPos ap = new AlunoPos(345678901, "Yoshi", 7.5, 5.5, 4.2);

//        Criando a escola
        Escola e = new Escola("Banda Tecnológica");

//        Cadastrando os alunos na escola
        e.adicionarAluno(ag);
        e.adicionarAluno(af);
        e.adicionarAluno(ap);

//        Testando métodos
        System.out.println("Todos os alunos:");
        e.exibeTodos();
        System.out.println("-".repeat(6));

        System.out.println("Alunos de Graduação:");
        e.exibeAlunoGraduacao();
        System.out.println("-".repeat(6));

        System.out.println("Alunos aprovados:");
        e.exibeAprovados();
        System.out.println("-".repeat(6));

        System.out.println("Buscando aluno do RA: 123456789");
        e.buscaAluno(123456789);
        System.out.println("-".repeat(6));

        System.out.println("Nota dos alunos:");
        System.out.printf("%s: %.2f \n", af.getNome(), af.calcularMedia());
        System.out.printf("%s: %.2f \n", ag.getNome(), ag.calcularMedia());
        System.out.printf("%s: %.2f \n", ap.getNome(), ap.calcularMedia());
    }
}
