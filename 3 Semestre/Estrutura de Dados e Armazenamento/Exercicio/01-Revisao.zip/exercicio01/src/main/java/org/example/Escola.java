package org.example;

import java.util.ArrayList;
import java.util.List;

public class Escola {
    private String nome;
    private List<Aluno> listAluno;

    public Escola(String nome) {
        this.nome = nome;
        this.listAluno = new ArrayList();
    }

    public void adicionarAluno(Aluno a){
        this.listAluno.add(a);
    }

    public void exibeTodos(){
        for (Aluno aluno: listAluno) {
            System.out.println(aluno.getNome());
        }
    }

    public void exibeAlunoGraduacao(){
        for (Aluno aluno: listAluno) {
            if (aluno instanceof AlunoGraduacao) {
                System.out.println(aluno.getNome());
            }
        }
    }

    public void exibeAprovados(){
        for (Aluno aluno: listAluno){
            if (aluno.calcularMedia() >= 6){
                System.out.println(aluno.getNome());
            }
        }
    }

    public void buscaAluno(Integer ra){
        for (Aluno aluno: listAluno){
            if (aluno.getRa().equals(ra)){
                System.out.println(aluno.getNome());
                return;
            }
        }
        System.out.println("Aluno não encontrado");
    }
}
