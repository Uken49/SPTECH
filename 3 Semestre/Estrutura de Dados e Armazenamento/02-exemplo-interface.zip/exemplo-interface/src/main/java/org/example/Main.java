package org.example;

public class Main {
    public static void main(String[] args) {

//        Criando os serviços
        Servico garcom = new Servico("Servir as mesas",20.49);
        Servico cozinheiro = new Servico("Cozinhar comida",15.0);

//        Criando os produtos
        Alimento canelone = new Alimento(100,"Uma massa de lasanha enrolado com queijo e presunto", 28.59, 23);
        Alimento manga = new Alimento(101, "Uma fruta que eu não sei descascar",6.20,89);

//        Criando os perfumes
        Perfume malbec = new Perfume(200, "Um perfume caro", 179.9, "Boa");
        Perfume dolceGabbana = new Perfume(201, "Achei que malbec era caro, mas meu amigo...", 549.99, "Deve ser boa pelo preço");

        Tributo brasil = new Tributo();

//        Testando métodos
        brasil.adicionaTributavel(garcom);
        brasil.adicionaTributavel(cozinheiro);
        brasil.adicionaTributavel(canelone);
        brasil.adicionaTributavel(manga);
        brasil.adicionaTributavel(malbec);
        brasil.adicionaTributavel(dolceGabbana);

        System.out.printf("Soma de todos os tributos: %.2f \n",brasil.calculaTotalTributo());

        System.out.println("-".repeat(7));
        brasil.exibeTodos();
    }
}