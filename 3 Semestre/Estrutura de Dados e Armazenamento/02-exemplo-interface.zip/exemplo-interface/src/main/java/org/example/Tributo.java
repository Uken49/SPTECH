package org.example;

import java.util.ArrayList;
import java.util.List;

public class Tributo {
    private List<Tributavel> listaTributavel = new ArrayList();

    public void adicionaTributavel(Tributavel t){
        this.listaTributavel.add(t);
    }

    public double calculaTotalTributo(){
        Double soma = 0.0;

        for (Tributavel lista: listaTributavel) {
            soma += lista.getValorTributo();
        }

        return soma;
    }

    public void exibeTodos(){
        for (Tributavel lista : listaTributavel){
            System.out.println(lista.toString());
        }
    }

    public Tributo() {
        listaTributavel = new ArrayList();
    }

}
