package org.example;

public interface Tributavel {

    public Double getValorTributo();
}
