package org.example;

public class Alimento extends Produto{

//    Atributo
    private Integer quantidadeVitamina;

    @Override
    public Double getValorTributo() {
        return getPreco() * 0.15;
    }

//    Construtor

    public Alimento(Integer codigo, String descricao, Double preco, Integer quantidadeVitamina) {
        super(codigo, descricao, preco);
        this.quantidadeVitamina = quantidadeVitamina;
    }

//    toString()

    @Override
    public String toString() {
        return "Alimento:" +
                "\nQtd de Vitamina= " + quantidadeVitamina +
                super.toString();
    }
}
