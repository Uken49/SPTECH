package org.example;

public class Servico implements Tributavel {
    public String descricao;
    public Double preco;

    @Override
    public Double getValorTributo() {
        return this.preco * 0.12;
    }

    public Servico(String descricao, Double preco) {
        this.descricao = descricao;
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "Servico:" +
                "\ndescricao= " + descricao +
                "\npreco= " + preco + "\n" +
                "-".repeat(7);
    }
}
