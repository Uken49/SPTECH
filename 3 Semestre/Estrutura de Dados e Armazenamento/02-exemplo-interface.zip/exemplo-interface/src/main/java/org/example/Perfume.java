package org.example;

public class Perfume extends Produto{
    private String fragrancia;

    @Override
    public Double getValorTributo() {
        return getPreco() * 0.27;
    }

    public Perfume(Integer codigo, String descricao, Double preco, String fragrancia) {
        super(codigo, descricao, preco);
        this.fragrancia = fragrancia;
    }

    @Override
    public String toString() {
        return "Perfume: " +
                "\nfragrancia= " + fragrancia +
                super.toString();
    }
}
