package org.example;

public abstract class Produto implements Tributavel {

//    Atributos

    private Integer codigo;
    private String descricao;
    private Double preco;

//    Construtor

    public Produto(Integer codigo, String descricao, Double preco) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "\nProduto:" +
                "\ncódigo= " + codigo +
                "\ndescrição= " + descricao  +
                "\npreco= " + preco +
                "\ntributo= " + getValorTributo() + "\n" +
                "-".repeat(7);
    }

    public Double getPreco() {
        return preco;
    }
}
