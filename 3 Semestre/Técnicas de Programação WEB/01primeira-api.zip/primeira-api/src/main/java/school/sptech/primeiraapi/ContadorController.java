package school.sptech.primeiraapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // Converte essa classe para um controladora
@RequestMapping("/contadores") // Um padrão de URI para controller
public class ContadorController {

    private int contador;

    @GetMapping // Transforma o método em um endpoint (GET)
    public String contar(){
        contador++;
        return String.format("Resultado: %d", contador);
    }
}
