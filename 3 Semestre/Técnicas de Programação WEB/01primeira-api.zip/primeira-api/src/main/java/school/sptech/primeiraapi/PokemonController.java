package school.sptech.primeiraapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/pokemon")
public class PokemonController {

    private List<String> pokemon = new ArrayList();

    @GetMapping("/")
    public String getQuantidade(){
        return "Quantidade de Pokemon cadastrados: " + this.pokemon.size();
    }

    @GetMapping("/cadastrar/{nome}")
    public String cadastrarPokemon(@PathVariable String nome){
        this.pokemon.add(nome);
        return "Pokemon cadastrado com suceeso bae";
    }

    @GetMapping("/recuperar/{id}")
    public String recuperarPokemon(@PathVariable int id){
        if (id > pokemon.size() || id < 0){
            return "Pokemon não encontrado bae";
        }
        return "Pokemon:" + this.pokemon.get(id-1);
    }

    @GetMapping("/excluir/{id}")
    public String excluirPokemon(@PathVariable int id){
        this.pokemon.remove(id - 1);
        return  ("Pokemon deletado com sucesso bae");
    }

    @GetMapping("/atualizar/{id}/{nome}")
    public String atualizarPokemon(
            @PathVariable Integer id
            , @PathVariable String nome
    ){
        this.pokemon.set(id-1, nome);
        return ("Pokemon atualizado com sucesso bae");
    }
}
