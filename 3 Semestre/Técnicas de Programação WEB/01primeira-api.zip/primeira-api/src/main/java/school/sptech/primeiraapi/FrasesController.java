package school.sptech.primeiraapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// @Controller // para servir páginas
@RestController // Converte essa classe para um controladora
@RequestMapping("/frases") // Um padrão de URI para controller
public class FrasesController {

    @GetMapping // Transforma o método em um endpoint (GET)
    public String hello(){
        return "Olá Mundo";
    }

    @GetMapping ("/bom-dia")
    public String bomDia(){
        return "Bom dia mozão!!!! :)";
    }

    @GetMapping ("/boa-tarde")
    public String boaTarde(){
        return "Café ??? '______'";
    }

    @GetMapping ("/boa-noite")
    public String boaNoite(){
        return "Vou mimir mori ^-^";
    }
}
