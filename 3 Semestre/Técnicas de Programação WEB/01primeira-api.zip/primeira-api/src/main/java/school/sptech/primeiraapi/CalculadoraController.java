package school.sptech.primeiraapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // Converte essa classe para um controladora
@RequestMapping("/calculadoras") // Um padrão de URI para controller
public class CalculadoraController {

    // /somar/n1/n2
    // Resultado: x

    @GetMapping("/somar/{n1}/{n2}")
    public String somar(
            @PathVariable int n1
            ,@PathVariable int n2
    ){
        return String.format("Resultado: %d", (n1 + n2));
    }
}
