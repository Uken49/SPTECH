package school.sptech.projeto2api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto2ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
