package school.sptech.projeto2api;

import jakarta.websocket.server.PathParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

// Quando um Objeto é retornado, o Spring retorna um JSON
// O que é retornado no JSON são APENAS os métodos que comecem com:
//  - has
//  - is
//  - get

@RestController
@RequestMapping("/frutas")
public class FrutaController {

    private List<Fruta> frutas = new ArrayList();

    @GetMapping
    public List<Fruta> listar(){
        return frutas;
    }

    @GetMapping("/favorito")
    public Fruta getFavorita(){
        return new Fruta("Goiaba",4.99,20,false);
    }

    @GetMapping("/cadastrar/{nome}/{preco}/{quantidade}/{semente}")
    public Fruta cadastrarUmaFruta
            (@PathVariable String nome
            ,@PathVariable double preco
            ,@PathVariable int quantidade
            ,@PathVariable boolean semente
             )
    {
        Fruta novaFruta = new Fruta(nome, preco, quantidade, semente);
        frutas.add(novaFruta);
        return novaFruta;
    }

    @GetMapping("/recuperar/{indice}")
    public Fruta buscarPorIndice(@PathVariable int indice){

        if (indice >= 0 && indice <= frutas.size() - 1){
            return frutas.get(indice);
        }

        return null;
    }

    @GetMapping("/atualizar/{indice}/{nome}/{preco}/{quantidade}/{semente}")
    public Fruta atualizarFruta
            (@PathVariable int indice
            ,@PathVariable String nome
            ,@PathVariable double preco
            ,@PathVariable int quantidade
            ,@PathVariable boolean semente
    )
    {
        frutas.set(indice, new Fruta(nome, preco, quantidade,semente));
        return frutas.get(indice);
    }
}
