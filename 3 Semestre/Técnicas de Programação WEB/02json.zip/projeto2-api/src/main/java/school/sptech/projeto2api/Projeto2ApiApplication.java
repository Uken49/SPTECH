package school.sptech.projeto2api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto2ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projeto2ApiApplication.class, args);
	}

}
