package school.sptech.login03221027helder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login03221027HelderApplicationTests {

	@Test
	void contextLoads() {
	}

}
