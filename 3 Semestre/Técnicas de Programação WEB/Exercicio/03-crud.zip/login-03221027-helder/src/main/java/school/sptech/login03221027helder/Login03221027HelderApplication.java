package school.sptech.login03221027helder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login03221027HelderApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login03221027HelderApplication.class, args);
	}

}
