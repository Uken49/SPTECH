package school.sptech.exercicioherois;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioHeroisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioHeroisApplication.class, args);
	}

}
