package school.sptech.exercicioherois;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/herois")
public class HeroisController {

    private List<Heroi> listaDeHeroi = new ArrayList<>();

    @GetMapping
    public Heroi exibirTodosHerois(){
        return Heroi;
    }

    @GetMapping("/{indice}")
    public Heroi exibirUmHeroi(@PathVariable int indice){

        return listaDeHeroi.get(indice);
    }

    @GetMapping("/cadastrar/{nome}/{habilidade}/{idade}/{forca}/{vivo}")
    public Heroi cadastrarUmHeroi
            (
                    @PathVariable String nome
                    ,@PathVariable String habilidade
                    ,@PathVariable int idade
                    ,@PathVariable double forca
                    ,@PathVariable boolean vivo
            ){

        return new Heroi(nome, habilidade, idade, forca, vivo);
    }

    @GetMapping("/atualizar/{indice}/{nome}/{habilidade}/{idade}/{forca}/{vivo}")
    public Heroi atualizarUmHeroiEspecifico(){
        listaDeHeroi.set(indice, new Heroi(nome, habilidade, idade, forca, vivo));
        return listaDeHeroi.get(indice);
    }

    @GetMapping("/remover/{indice}")
    public String removerUmHeroiEspecifico(@PathVariable String indice){

        listaDeHeroi.remove(indice);
        return "Heroi removido com sucesso";
    }

    @GetMapping("/consulta/{nome}")
    public Heroi  consultarHeroisComAPalavra(){

        return Heroi;
    }
}
