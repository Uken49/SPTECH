package school.sptech.exercicioherois;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/herois")
public class HeroisController {

    private List<Heroi> listaDeHerois = new ArrayList<>();

    @GetMapping // Raiz
    public List<Heroi> exibirTodosHerois(){

        return listaDeHerois;
    }

    @GetMapping("/{indice}")
    public Heroi exibirUmHeroi(@PathVariable int indice){

        return listaDeHerois.get(indice);
    }

    @GetMapping("/cadastrar/{nome}/{habilidade}/{idade}/{forca}/{vivo}")
    public Heroi cadastrarUmHeroi
            (
                    @PathVariable String nome
                    ,@PathVariable String habilidade
                    ,@PathVariable int idade
                    ,@PathVariable double forca
                    ,@PathVariable boolean vivo
            ){
        listaDeHerois.add(new Heroi(nome, habilidade, idade, forca, vivo));
        return listaDeHerois.get(listaDeHerois.size() - 1);
    }

    @GetMapping("/atualizar/{indice}/{nome}/{habilidade}/{idade}/{forca}/{vivo}")
    public Heroi atualizarUmHeroiEspecifico(
            @PathVariable int indice
            ,@PathVariable String nome
            ,@PathVariable String habilidade
            ,@PathVariable int idade
            ,@PathVariable double forca
            ,@PathVariable boolean vivo
            ){
        listaDeHerois.set(indice, new Heroi(nome, habilidade, idade, forca, vivo));
        return listaDeHerois.get(indice);
    }

    @GetMapping("/remover/{indice}")
    public String removerUmHeroiEspecifico(@PathVariable int indice){

        listaDeHerois.remove(indice);
        return "Heroi removido com sucesso";
    }

    @GetMapping("/consulta/{nome}")
    public List<Heroi> consultarHeroisComAPalavra(@PathVariable String nome){
        List<Heroi> heroisComAPalavra = new ArrayList<>();

        for (Heroi heroi:
             listaDeHerois) {

            if (heroi.getNome().contains(nome)) heroisComAPalavra.add(heroi);
        }

        return heroisComAPalavra;
    }
}
