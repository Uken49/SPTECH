package school.sptech.exercicioherois;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioHeroisApplicationTests {

	@Test
	void contextLoads() {
	}

}
