package school.sptech.projeto3api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto3ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
