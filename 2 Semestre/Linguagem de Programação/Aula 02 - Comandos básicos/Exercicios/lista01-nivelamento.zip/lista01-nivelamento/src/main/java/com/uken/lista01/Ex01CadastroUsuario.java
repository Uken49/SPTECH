package com.uken.lista01;

import java.util.Scanner;

public class Ex01CadastroUsuario {
    /*
        1-Seja executável
        2-Solicite o login do cliente
        3-Solicite a senha do cliente
        4-Solicite a quantidade de vezes que o usuário aceita errar a senha antes do bloqueio
        5-Exiba uma frase como esta:
        "Seu login é L e sua senha é S.Você tem T tentativas antes de ser bloqueado" 
        6-Use interpolação
    */
    public static void main(String[] args) {
        /*
            ++
            --
            -=
            +=
        
            Math.pow(x, y);
        */
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Digite nome");
        String login = input.nextLine();
        
        System.out.println("Digite senha");
        String senha = input.nextLine();
        
        
    }
}
