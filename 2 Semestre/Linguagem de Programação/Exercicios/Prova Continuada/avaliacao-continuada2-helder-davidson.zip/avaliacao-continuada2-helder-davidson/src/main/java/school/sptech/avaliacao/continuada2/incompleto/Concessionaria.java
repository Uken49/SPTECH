package school.sptech.avaliacao.continuada2.incompleto;

import java.util.Objects;

/*

 Substitua os valores abaixo com seus dados:

 RA: {03221027}
 NOME: {Helder Davidson Rodrigues Alvarenga}
 TURMA: {1°CCO - 2° Semestre}
  
 ATENÇÃO!!!
 RESOLVA OS ERROS DE COMPILAÇÃO ANTES DE RODAR QUALQUER TESTE

 */
public class Concessionaria {
    private String nome;
    private Integer quantidadeVendas;
    private Integer quantidadeDescontosAplicados;
    private Double totalVendido;

    public Concessionaria(String nome) {
        this.nome = nome;
        this.quantidadeVendas = 0;
        this.quantidadeDescontosAplicados = 0;
        this.totalVendido = 0.0;
    }
    
    public void aumentarEstoque(Veiculo veiculo, Integer quantidade){
        
        if (Objects.isNull(veiculo) || Objects.isNull(quantidade)) {
            return;
        }
        
        if (quantidade <= 0) {
            return;
        }
        
        Integer quantidadeFinal = quantidade + veiculo.getQuantidadeEstoque();
        
        veiculo.setQuantidadeEstoque(quantidadeFinal);
    }
    
    public void realizarVenda(Veiculo veiculo){
        
        if (Objects.isNull(veiculo)) {
            return;
        }
        
        if (veiculo.getQuantidadeEstoque() <= 0) {
            return;
        }
        
        if (veiculo.getValorTabela() <= 0) {
            return;
        }
        
        Integer quantidadeFinal = veiculo.getQuantidadeEstoque() - 1;
        veiculo.setQuantidadeEstoque(quantidadeFinal);
        
        this.totalVendido += veiculo.getValorTabela();
        this.quantidadeVendas++;
        
    }
    
    public void realizarVenda(Veiculo veiculo, Double porcentagemDesconto){
        
        if (Objects.isNull(veiculo)) {
            return;
        }
        
        if (veiculo.getQuantidadeEstoque() <= 0) {
            return;
        }
        
        if (veiculo.getValorTabela() <= 0) {
            return;
        }
        
        if (Objects.isNull(porcentagemDesconto) || porcentagemDesconto <= 0) {
            return;
        }
        
        Integer quantidadeFinal = veiculo.getQuantidadeEstoque() - 1;
        veiculo.setQuantidadeEstoque(quantidadeFinal);
        
        Double valorDesconto = veiculo.getValorTabela() * ( porcentagemDesconto / 100.0);
        Double valorFinal = veiculo.getValorTabela() - valorDesconto;
                
        this.totalVendido += valorFinal;
        this.quantidadeVendas++;
        this.quantidadeDescontosAplicados++;
    }
    
    public Double getPercentualVendasComDesconto(){
        Double percentualVenda;
        
        if (this.quantidadeVendas == 0) {
            percentualVenda = 0.0;
    
        }else{
            percentualVenda = (this.quantidadeDescontosAplicados * 100.0) / this.quantidadeVendas;
        }
        
        return percentualVenda;
    }
    
    public String getNome() {
        return nome;
    }

    public Integer getQuantidadeVendas() {
        return quantidadeVendas;
    }
    
    public Integer getQuantidadeDescontosAplicados() {
        return quantidadeDescontosAplicados;
    }

    public Double getTotalVendido() {
        return totalVendido;
    }

}
